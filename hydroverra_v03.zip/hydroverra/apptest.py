from streamlit.testing.v1 import AppTest
at = AppTest.from_file("app.py", default_timeout=180).run()
assert not at.exception, at.exception
print("sliders:", {s.key: s.value for s in at.slider if s.key in ("el_kw", "tank_kg", "fc_kw", "load_kw")})
print("suppliers:", {k: at.session_state[k] for k in ("sup_electrolyser", "sup_fuel_cell", "sup_tank")})
at.button(key="solve_btn").click().run()
assert not at.exception, at.exception
print("solve:", [(m.label, m.value) for m in at.metric][:3])
at.button(key="auto_btn").click().run()
assert not at.exception, at.exception
print("autonomy:", [e.value[:70] for e in at.error if "FAIL" in e.value or "PASS" in e.value])
at.selectbox(key="sup_electrolyser").select("PEM Supplier B").run()
at.button(key="auto_btn").click().run()
print("autonomy (supplier B, 70.2 kW slider):", [e.value[:70] for e in list(at.error) + list(at.success) if "FAIL" in e.value or "PASS" in e.value])
at.selectbox(key="preset").select("Manual").run()
assert not at.exception, at.exception
cmp_btn = [b for b in at.button if b.label == "Compare suppliers"][0]
cmp_btn.click().run(); assert not at.exception, at.exception
print("compare rows:", len(at.session_state["cmp"]))
