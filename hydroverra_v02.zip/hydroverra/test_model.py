import numpy as np
from dataclasses import replace
from model import Design, run, load_suppliers, apply_supplier, compare_suppliers, wind_cf
from weather import synthetic


def wx(days=7, start="2023-01-10"):
    w = synthetic(57.15, 2023)
    return w.loc[start:].iloc[: 24 * days]


def test_balance_and_limits():
    d = Design(pv_kw=150, wind_kw=50)
    out = run(d, wx())
    df, s = out["df"], out["summary"]
    bal = df.pv_kw + df.wind_kw + df.fuel_cell_kw + df.shortage_kw - df.load_kw - df.electrolyser_kw - df.curtail_kw
    assert bal.abs().max() < 1e-6
    on = df.electrolyser_kw[df.electrolyser_kw > 1e-6]
    assert on.empty or on.min() >= d.el_kw * d.el_min - 1e-6
    assert df.tank_kg.max() <= d.tank_kg + 1e-6
    kg_in = (df.electrolyser_kw / d.el_kwh_per_kg).sum()
    kg_out = (df.fuel_cell_kw / d.fc_kwh_per_kg).sum()
    assert abs(kg_in - kg_out) < 1e-3  # tank is balanced: start level = end level
    assert 0 <= s["served_pct"] <= 100


def test_no_generation_means_no_service():
    s = run(Design(pv_kw=0, wind_kw=0), wx(2))["summary"]
    assert abs(s["served_pct"]) < 1e-6


def test_wind_curve():
    cf = wind_cf([0, 3, 12, 20, 26], 3, 12, 25)
    assert cf[0] == 0 and cf[2] == 1 and cf[3] == 1 and cf[4] == 0


def test_supplier_compare():
    sup = load_suppliers()
    t = compare_suppliers(Design(pv_kw=150), "electrolyser", sup, wx(3))
    assert len(t) == 2 and (t.capex > 0).all()


def test_parse_open_meteo():
    from weather import parse_open_meteo
    p = {"hourly": {"time": ["2023-01-01T00:00", "2023-01-01T01:00"],
                    "shortwave_radiation": [0, 5.0], "wind_speed_100m": [7.0, None],
                    "temperature_2m": [3.0, 3.1]}}
    df = parse_open_meteo(p)
    assert list(df.columns) == ["ghi_wm2", "wind_ms", "temp_c"] and df.wind_ms.iloc[1] == 7.0
