"""HydroVerra sizing and supplier comparison. Run: uv run streamlit run app.py"""
from __future__ import annotations

from dataclasses import replace

import pandas as pd
import streamlit as st

from model import Design, SUPPLIERS_CSV, apply_supplier, compare_suppliers, run, sweep
from weather import ABERDEEN, load_weather

st.set_page_config(page_title="HydroVerra model", layout="wide")
st.title("HydroVerra: dispatch and supplier model")
st.caption("Hourly energy balance with oemof-solph. Steady state, no degradation yet.")

if "suppliers" not in st.session_state:
    st.session_state.suppliers = pd.read_csv(SUPPLIERS_CSV)
sup: pd.DataFrame = st.session_state.suppliers


@st.cache_data(show_spinner="Loading weather...")
def get_weather(lat, lon, year):
    return load_weather(lat, lon, year)


def pick(cat: str) -> pd.Series | None:
    names = ["(defaults)"] + sup[sup.category == cat].supplier.tolist()
    choice = st.sidebar.selectbox(f"{cat} supplier", names, key=f"sup_{cat}")
    if choice == "(defaults)":
        return None
    return sup[(sup.category == cat) & (sup.supplier == choice)].iloc[0]


# ---------------- Sidebar ----------------
st.sidebar.header("Site and period")
lat = st.sidebar.number_input("Latitude", value=ABERDEEN[0], format="%.2f")
lon = st.sidebar.number_input("Longitude", value=ABERDEEN[1], format="%.2f")
year = st.sidebar.number_input("Weather year", 2015, 2024, 2023)
upload = st.sidebar.file_uploader("Or upload weather CSV (time, ghi_wm2, wind_ms)", type="csv")
if upload is not None:
    wx_all = pd.read_csv(upload, index_col=0, parse_dates=True)
    src = "uploaded file"
else:
    wx_all, src = get_weather(lat, lon, int(year))
start = st.sidebar.date_input("Start date", value=pd.Timestamp(f"{int(year)}-01-10"))
days = st.sidebar.slider("Days", 1, 90, 7)

st.sidebar.header("Design (sliders)")
use_pv = st.sidebar.checkbox("Solar PV", True)
use_wind = st.sidebar.checkbox("Wind turbine", True)
pv_kw = st.sidebar.slider("PV size (kWp)", 0, 500, 100, 5, disabled=not use_pv)
wind_kw = st.sidebar.slider("Wind size (kW)", 0, 300, 30, 5, disabled=not use_wind)
el_kw = st.sidebar.slider("Electrolyser (kW in)", 10, 500, 100, 5)
tank_kg = st.sidebar.slider("H2 tank (kg)", 1, 500, 40, 1)
fc_kw = st.sidebar.slider("Fuel cell (kW out)", 0, 200, 30, 5)
load_kw = st.sidebar.slider("Load (kW, flat)", 1, 200, 20, 1)

st.sidebar.header("Suppliers")
design = Design(
    pv_kw=pv_kw if use_pv else 0, wind_kw=wind_kw if use_wind else 0,
    el_kw=el_kw, tank_kg=tank_kg, fc_kw=fc_kw, load_kw=load_kw,
)
chosen = []
for cat in ["pv", "wind", "electrolyser", "fuel_cell", "tank"]:
    row = pick(cat)
    if row is not None:
        design = apply_supplier(design, row)
        chosen.append(row)

t0 = pd.Timestamp(start, tz="UTC")
wx = wx_all.loc[t0 : t0 + pd.Timedelta(days=days) - pd.Timedelta(hours=1)]

if "SYNTHETIC" in src:
    st.error(f"Weather is SYNTHETIC ({src}). Results are NOT Aberdeen results. Check internet access.")
else:
    st.caption(f"Weather source: {src}. Hours in period: {len(wx)}")
if any(str(r.get("status")) == "PLACEHOLDER" for r in chosen) or not chosen:
    st.warning("Supplier values are PLACEHOLDERS or defaults. Do not use these results as quotes.")
if len(wx) < 24:
    st.stop()

tab_run, tab_cmp, tab_sweep, tab_sup, tab_about = st.tabs(
    ["Result", "Compare suppliers", "Sweep a size", "Supplier table", "Assumptions"])

with tab_run:
    if st.button("Solve", key="solve_btn", type="primary"):
        st.session_state.last = run(design, wx)
    out = st.session_state.get("last")
    if out is None:
        st.info("Set the sliders and press Solve.")
    else:
        s, df = out["summary"], out["df"]
        c = st.columns(5)
        c[0].metric("Load served", f"{s['served_pct']:.1f} %")
        c[1].metric("Unserved", f"{s['unserved_kwh']:.0f} kWh")
        c[2].metric("H2 produced", f"{s['h2_kg']:.1f} kg")
        c[3].metric("Curtailed", f"{s['curtailed_kwh']:.0f} kWh")
        c[4].metric("Capex (table units)", f"{s['capex']:,.0f}")
        st.caption(f"Electrolyser starts: {s['electrolyser_starts']} | solve time {s['solve_seconds']} s")
        st.subheader("Power (kW)")
        st.line_chart(df[["pv_kw", "wind_kw", "load_kw", "electrolyser_kw", "fuel_cell_kw", "shortage_kw"]])
        st.subheader("H2 in tank (kg)")
        st.line_chart(df[["tank_kg"]])
        st.download_button("Download hourly results (CSV)", df.to_csv().encode(), "hydroverra_results.csv")

with tab_cmp:
    cat = st.selectbox("Category to compare", ["pv", "wind", "electrolyser", "fuel_cell", "tank"])
    if st.button("Compare suppliers"):
        # use the current design, but re-apply each supplier of the chosen category
        st.session_state.cmp = compare_suppliers(design, cat, sup, wx)
    if "cmp" in st.session_state:
        t = st.session_state.cmp
        st.dataframe(t[["supplier", "status", "served_pct", "unserved_kwh", "h2_kg",
                        "curtailed_kwh", "electrolyser_starts", "capex"]].round(1), hide_index=True)
        st.bar_chart(t.set_index("supplier")[["unserved_kwh"]])

with tab_sweep:
    fld = st.selectbox("Size to sweep", ["pv_kw", "wind_kw", "tank_kg", "el_kw", "fc_kw"])
    lo, hi = st.columns(2)
    vmin = lo.number_input("From", value=0.0)
    vmax = hi.number_input("To", value=300.0)
    steps = st.slider("Steps", 3, 15, 7)
    if st.button("Run sweep"):
        vals = [vmin + i * (vmax - vmin) / (steps - 1) for i in range(steps)]
        st.session_state.sw = (fld, sweep(design, fld, vals, wx))
    if "sw" in st.session_state:
        f, t = st.session_state.sw
        st.line_chart(t.set_index(f)[["unserved_kwh"]])
        st.dataframe(t[[f, "served_pct", "unserved_kwh", "h2_kg", "curtailed_kwh", "capex"]].round(1), hide_index=True)
        ok = t[t.served_pct >= 99.99]
        if len(ok):
            st.success(f"Smallest tested {f} with 100 % served: {ok[f].min():.0f}")
        else:
            st.warning(f"No tested {f} reaches 100 % served. Change other sizes or the range.")

with tab_sup:
    st.write("Edit values. Set status to QUOTE or DATASHEET when the number is real.")
    st.session_state.suppliers = st.data_editor(sup, num_rows="dynamic", hide_index=True)
    if st.button("Save table to suppliers.csv"):
        st.session_state.suppliers.to_csv(SUPPLIERS_CSV, index=False)
        st.success("Saved.")

with tab_about:
    st.markdown("""
- PV: capacity factor = horizontal irradiance / 1000 x performance ratio. No tilt or temperature model. Aberdeen winter output can differ from a tilted array. Replace with PVGIS data later.
- Wind: generic power curve (cubic between cut-in and rated) from 100 m ERA5 wind. Replace with the real curve from the supplier.
- Electrolyser: minimum load, kWh per kg, start-up cost (placeholder 5), minimum uptime 2 h. Efficiency is constant. No degradation, no warm-up.
- Tank: starts at 50 %, ends at 50 % (cyclic). No compressor energy, no losses.
- Fuel cell: constant efficiency. Minimum load only if set in the supplier table.
- Shortage is allowed at a high cost, so the model shows unserved load instead of failing.
- Capex is the sum of size x supplier unit cost. It has no installation, no opex, no lifetime.
""")
