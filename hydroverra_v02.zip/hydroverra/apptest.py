from streamlit.testing.v1 import AppTest
at = AppTest.from_file("app.py", default_timeout=120).run()
assert not at.exception, at.exception
print("banners:", [e.value[:60] for e in at.error], [w.value[:60] for w in at.warning])
at.button(key="solve_btn").click().run()
assert not at.exception, at.exception
print("metrics:", [(m.label, m.value) for m in at.metric])

at.selectbox(key="sup_electrolyser").select("PEM Supplier B").run()
at.button(key="solve_btn").click().run()
print("with supplier B:", [(m.label, m.value) for m in at.metric][:2], "capex", at.metric[4].value)
cmp_btn = [b for b in at.button if b.label == "Compare suppliers"][0]
cmp_btn.click().run()
assert not at.exception, at.exception
print("compare rows:", len(at.session_state["cmp"]))
sw_btn = [b for b in at.button if b.label == "Run sweep"][0]
sw_btn.click().run()
assert not at.exception, at.exception
print("sweep rows:", len(at.session_state["sw"][1]))
