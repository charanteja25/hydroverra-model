# HydroVerra model (v0.2)

    uv sync
    uv run streamlit run app.py        # sliders, supplier comparison, sweeps
    uv run --with pytest python -m pytest -q test_model.py

- First start downloads Aberdeen weather (Open-Meteo ERA5, no key) and caches it in data/.
- If the red "SYNTHETIC" banner shows, the download failed. Results are then NOT Aberdeen results.
- Edit suppliers in the "Supplier table" tab or in suppliers.csv. All rows are PLACEHOLDER until you replace them.
